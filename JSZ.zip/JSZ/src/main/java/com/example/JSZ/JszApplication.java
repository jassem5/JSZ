package com.example.JSZ;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JszApplication {

	public static void main(String[] args) {
		SpringApplication.run(JszApplication.class, args);
	}

}
