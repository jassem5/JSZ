package com.example.JSZ;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JszApplicationTests {

	@Test
	void contextLoads() {
	}

}
